package com.test.wiki.frurl.mapper;

import java.util.HashMap;
import java.util.Map;

import org.osgi.service.component.annotations.Component;

import com.liferay.portal.kernel.portlet.DefaultFriendlyURLMapper;
import com.liferay.portal.kernel.portlet.FriendlyURLMapper;
import com.liferay.portal.kernel.portlet.LiferayPortletURL;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.wiki.escape.WikiEscapeUtil;

/**
 * @author V0066801
 */
@Component(
	immediate = true,
	property = {
			"com.liferay.portlet.friendly-url-routes=META-INF/friendly-url-routes/routes.xml","javax.portlet.name=com_liferay_wiki_web_portlet_WikiPortlet",
			"service.ranking:Integer=100"},
	service = FriendlyURLMapper.class
)
public class WikiFriendlyUrlMapperNew  extends DefaultFriendlyURLMapper{



	@Override
	public String getMapping() {
		System.out.println("Custom Friendly URL mapper called.");
		return _MAPPING;
	}

	private static final String _MAPPING = "wiki";



}
package com.grpmax.otp.navigation;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.taglib.BaseDynamicInclude;
import com.liferay.portal.kernel.servlet.taglib.DynamicInclude;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;

/**
 * @author vishal
 */
@Component(
	immediate = true,property={"service.ranking:Integer=100" },
	service = DynamicInclude.class
)
public class OTPNavigation extends BaseDynamicInclude {

	@Override
	public void include(
			HttpServletRequest request, HttpServletResponse response,
			String key)
		throws IOException {

		String mvcRenderCommandName = ParamUtil.getString(
			request, "mvcRenderCommandName");

		ThemeDisplay themeDisplay = (ThemeDisplay)request.getAttribute(
			WebKeys.THEME_DISPLAY);
		
		if (mvcRenderCommandName.equals("/login/custom_otp")) {
			System.out.println("test");
				return;
			}
		System.out.println("testing");
		RequestDispatcher requestDispatcher =
				_servletContext.getRequestDispatcher(_JSP_PATH);

		try {
			requestDispatcher.include(request, response);
		}
		catch (ServletException se) {
			_log.error("Unable to include JSP " + _JSP_PATH, se);

			throw new IOException("Unable to include JSP " + _JSP_PATH, se);
		}
	}

	@Override
	public void register(
		DynamicInclude.DynamicIncludeRegistry dynamicIncludeRegistry) {
		System.out.println("testinggggggggggg");
		dynamicIncludeRegistry.register(
			"com.liferay.login.web#/navigation.jsp#pre");
	}

	@Reference(
		target = "(osgi.web.symbolicname=com.grpmax.otp.navigation)",
		unbind = "-"
	)
	protected void setServletContext(ServletContext servletContext) {
		System.out.println("testing register");
		_servletContext = servletContext;
	}

	private static final String _JSP_PATH =
		"/com.liferay.login.web/navigation/custom_otp.jsp";

	private static final Log _log = LogFactoryUtil.getLog(
			OTPNavigation.class);

	private ServletContext _servletContext;


}
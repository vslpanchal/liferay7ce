package fi.jguru.yubikey.otp.login.web.constants;

public class YubikeyConstants {

	public static final String SERVICE_NAME = "fi.jguru.yubikey.otp.login.web.configuration.YubikeyAuthenticationConfiguration";
}

package fi.jguru.yubikey.otp.login.web.constants;

public class WebKeys {

	public static final String YUBIKEY_LOGIN_USERID = "YUBIKEY_LOGIN_USERID";

}

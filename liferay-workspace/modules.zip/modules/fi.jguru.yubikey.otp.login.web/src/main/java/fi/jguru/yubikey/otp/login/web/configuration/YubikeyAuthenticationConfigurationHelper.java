package fi.jguru.yubikey.otp.login.web.configuration;

public interface YubikeyAuthenticationConfigurationHelper {

	public boolean isEnabled(long companyId);

}

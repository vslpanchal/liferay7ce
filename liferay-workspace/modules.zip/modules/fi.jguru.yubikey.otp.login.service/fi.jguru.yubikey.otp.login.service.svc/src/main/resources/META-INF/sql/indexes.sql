create unique index IX_CF780F64 on JGURU_YubikeyOTPKeyEntry (publicId[$COLUMN_LENGTH:75$]);
create index IX_CF6E346 on JGURU_YubikeyOTPKeyEntry (userId);